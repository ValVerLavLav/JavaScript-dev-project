
function randomArray(length) {

}

function splitArray(){


}